# 先端社会デザイン創成 技術紹介サイト
## Overview
**先端社会デザイン創成におけるグループワーク課題の認知工学技術紹介サイト**

## Architecture
![](./public/images/astro-architecture.png)

## Deployment
```bash
https://sousei-group14.vercel.app
```
